# ufespay_api

install mongodb https://docs.mongodb.com/manual/tutorial/install-mongodb-on-ubuntu/

install node

install npm

# install dependencies

npm install
ou
yarn

# start the database (on ubuntu):

sudo systemctl start mongod

# Serve the api (on localhost:3000)

npm run dev:server
ou
yarn dev:server